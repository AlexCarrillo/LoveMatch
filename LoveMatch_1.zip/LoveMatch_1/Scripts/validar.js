function validar(btn) 
{
    if ((document.getElementById("checkMen").checked || document.getElementById("checkWomen").checked ) &&
    	(document.getElementById("checkDate").checked || document.getElementById("checkCasual").checked)) 
    {
        btn.disabled=false;
    } 
    else 
    {
        alert(errorMessage);
    }
}